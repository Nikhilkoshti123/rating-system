<?php
defined('BASEPATH') or exit('No direct script access allowed');

class ApiModel extends CI_Model
{

	public function __construct()
	{
		parent::__construct();
	}

	public function CheckLoginAdmin($where){
		$this->db->where($where);
        $qry= $this->db->get('admin');
        return $qry->row();
	}
	
	
	public function insertAll($table,$data) {
	$this->db->insert($table, $data);
	return $this->db->insert_id();
	}
	
	
	
	public function getAll($table,$id,$order){
    $this->db->order_by($id,$order);
    $qry= $this->db->get($table);
    return $qry->result();
	} 

	public function getSingleCar($where){        
        $this->db->where($where);
        $qry= $this->db->get('car');
        return $qry->row();
    }

}
