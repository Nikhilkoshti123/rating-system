<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Api_c extends MY_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('file','directory'));
		$this->load->model('ApiModel');
	}

	public function Login_post() {	
	if($_SERVER['REQUEST_METHOD']=="POST") {
			$email = $this->post('email');
			$pass = md5($this->post('password'));
			
				$where = array('admin_email'=>$email,'admin_pass'=>$pass);
				$data = $this->ApiModel->CheckLoginAdmin($where);
			
			
			if(!empty($data)) {
				$this->response($data, 200);
			}else{
			$this->response([
				'status' => false,
				'message' => 'Login Failed',
			], 404); 
			}
		}else {
			$this->response([
				'status' => false,
				'message' => 'Login Failed',
			], 404); 
		}	
	}
	
	public function addCar_post() {
		if($_SERVER['REQUEST_METHOD']=="POST") {
		$updir = "/uploads/";
		$img = 'img';
		 
		$uploadfile = $this->do_upload($updir, $img);
		if($uploadfile == true){
					$insert =  array('brand'=>$this->post('brand'),
					'discription'=>$this->post('discription'),
					'price'=>$this->post('price'),
					'mileage'=>$this->post('mileage'),
					'seat'=>$this->post('seat'),
					'image'=>$uploadfile['file'],
						);
				$insertData = $this->ApiModel->insertAll('carlist',$insert);
					if($insertData == true){
						$this->response($insertData, 200);
					} else {
						$this->response([
				'status' => false,
				'message' => 'failed',
			], 404); 
					}
		} else {
			$this->response([
				'status' => false,
				'message' => 'Failed',
			], 404); 
		}			

		
		}else {
			$this->response([
				'status' => false,
				'message' => 'Wrong Request method',
			], 404); 
		}	
	}
	
	// image upload function with given parameter
	public function do_upload($updir, $img)
    {
		$new_name = uniqid();
	    $filepath = $_SERVER["DOCUMENT_ROOT"].'/api'.$updir; 
		$config['upload_path']=$filepath;
        $config['allowed_types']='jpg|png|jpeg';
        $config['max_size']='100000';
        $config['remove_space']=TRUE;
        $config['overwrite']=TRUE;

        $this->load->library('upload',$config);

        if ($this->upload->do_upload($img)) {
            $return = array(
                'result'=>'success', 
                'file'=> $this->upload->data(), 
                'error'=>'');
                return $return;

        } else {
            $return = array(
                'result'=>'failed',
                'file'=>'',
                'error'=> $this->upload->display_errors());
                return $return;
        }
	}
	
	public function CarList_get() {
		if($_SERVER['REQUEST_METHOD']=="GET") {
			$data = $this->ApiModel->getAll('carlist','car_id','desc');
			if($data == true){
				$this->response($data, 200);
			} else {
				$this->response([
				'status' => false,
				'message' => 'Failed Data',
			], 404); 
			}
		} else {
			$this->response([
				'status' => false,
				'message' => 'Wrong Request method',
			], 404); 
		}
	}
}
